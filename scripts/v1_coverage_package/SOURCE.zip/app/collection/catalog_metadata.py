"""Versioned compact excluded-catalog metadata; original wire evidence is authority."""
from .coverage import decode_page

POLICY='bounded-open-catalog-v4'


def compact(catalog, venue):
    # Excluded evidence must not occupy the bounded operating market table.
    # Column rows share page references; full source JSON remains in the journal.
    evidence=dict(version='excluded-catalog-1',source=venue,
        columns=['id','event_id','title','exclusion','page','occurrences'],pages=[],events=[],markets=[],side_counts={})
    # An excluded/unresolved parent cannot leave an operating orphan market.
    operating_events={r['id'] for r in catalog['events'] if not r.get('exclusion') and r.get('identity')!='unresolved'}
    for row in catalog['markets']:
        if row.get('event_id') not in operating_events:
            row['exclusion']=row.get('exclusion') or 'unresolved_parent_event'
    refs={}
    for kind in ('events','markets'):
        kept=[]
        for row in catalog[kind]:
            if not row.get('exclusion') and row.get('identity')!='unresolved':
                kept.append(row);continue
            proof=row['provenance'][0];key=proof['body_sha256']
            if key not in refs:
                refs[key]=len(evidence['pages'])
                evidence['pages'].append(dict(response_sha256=key,path=proof['path'],received_at=proof['received_at']))
            evidence[kind].append([row['id'],row.get('event_id',row['id']),str(row.get('title') or '')[:160],
                row.get('exclusion') or 'unresolved_native_identity',refs[key],row.get('occurrences',1)])
            for side in row.get('sides',[]):
                k=side['purchase_support'];evidence['side_counts'][k]=evidence['side_counts'].get(k,0)+1
        catalog[kind]=kept
    catalog['excluded_catalog']=evidence
    return catalog


def references(catalog):
    evidence=catalog.get('excluded_catalog',{})
    for kind in ('events','markets'):
        for row in evidence.get(kind,[]):
            yield dict(version='catalog-metadata-reference-1',source=evidence['source'],
                response_sha256=evidence['pages'][row[4]]['response_sha256'],entity='event' if kind=='events' else 'market',
                id=row[0],event_id=row[1])


def resolve(pages, ref):
    """Inspectable original metadata, resolved only on demand from complete bytes."""
    matches=[]
    for p in pages:
        if p.get('source')!=ref['source'] or p.get('body_sha256')!=ref['response_sha256'] or p.get('complete') is not True or p.get('status')!=200:continue
        _,data=decode_page(p)
        key='id' if ref['source']=='polymarket_us' else 'event_ticker' if ref['entity']=='event' else 'ticker'
        if ref['entity']=='event':candidates=data.get('events',[])
        elif 'markets' in data:candidates=data['markets']
        else:candidates=[m for e in data.get('events',[]) if str(e.get('id'))==ref['event_id'] for m in (e.get('markets') or [])]
        matches.extend(x for x in candidates if isinstance(x,dict) and str(x.get(key))==ref['id'])
    if len(matches)!=1:raise ValueError('Source metadata missing or ambiguous; no inferred reconstruction')
    return matches[0]
